import { useState, useEffect, useRef } from 'react'

// Custom Cursor Component
const CustomCursor = () => {
  const cursorRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cursor = cursorRef.current
    if (!cursor) return

    const moveCursor = (e: MouseEvent) => {
      cursor.style.left = e.clientX + 'px'
      cursor.style.top = e.clientY + 'px'
    }

    window.addEventListener('mousemove', moveCursor)
    return () => window.removeEventListener('mousemove', moveCursor)
  }, [])

  return (
    <div
      ref={cursorRef}
      className="fixed w-8 h-8 rounded-full border-2 border-red-600 pointer-events-none z-50 mix-blend-difference transition-transform duration-150 ease-out"
      style={{ transform: 'translate(-50%, -50%)' }}
    />
  )
}

// Animated Section Component
const AnimatedSection = ({ children, className = '', delay = 0 }: { children: React.ReactNode, className?: string, delay?: number }) => {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay)
        }
      },
      { threshold: 0.1 }
    )

    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [delay])

  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'} ${className}`}
    >
      {children}
    </div>
  )
}

// Glassmorphism Card Component
const GlassCard = ({ children, className = '' }: { children: React.ReactNode, className?: string }) => (
  <div className={`backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl ${className}`}>
    {children}
  </div>
)

// Navigation Component
const Navigation = () => {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navLinks = ['About', 'Services', 'Process', 'Work', 'FAQ']

  return (
    <nav className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${scrolled ? 'backdrop-blur-xl bg-black/50' : ''}`}>
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        <a href="#" className="font-display text-2xl font-bold bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent">
          AKASH
        </a>
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a key={link} href={`#${link.toLowerCase()}`} className="text-gray-300 hover:text-white transition-colors font-medium">
              {link}
            </a>
          ))}
          <a
            href="mailto:selectgadget56@gmail.com"
            className="px-6 py-2 bg-gradient-to-r from-red-600 to-red-700 rounded-full font-semibold hover:shadow-lg hover:shadow-red-500/30 transition-all duration-300"
          >
            Get Started
          </a>
        </div>
        <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {mobileMenuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>
      {mobileMenuOpen && (
        <div className="md:hidden bg-black/95 backdrop-blur-xl border-t border-white/10">
          <div className="flex flex-col p-6 gap-4">
            {navLinks.map((link) => (
              <a key={link} href={`#${link.toLowerCase()}`} className="text-gray-300 hover:text-white transition-colors font-medium py-2">
                {link}
              </a>
            ))}
            <a
              href="mailto:selectgadget56@gmail.com"
              className="px-6 py-3 bg-gradient-to-r from-red-600 to-red-700 rounded-full font-semibold text-center mt-2"
            >
              Get Started
            </a>
          </div>
        </div>
      )}
    </nav>
  )
}

// Hero Section
const Hero = () => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Grain Texture Overlay */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg"%3E%3Cfilter id="noiseFilter"%3E%3CfeTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="4" stitchTiles="stitch"/%3E%3C/filter%3E%3Crect width="100%25" height="100%25" filter="url(%23noiseFilter)"/%3E%3C/svg%3E")' }} />

      {/* Gradient Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600/20 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-red-900/30 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-red-600/10 to-transparent rounded-full blur-3xl" />

      <div className="container mx-auto px-6 relative z-10 text-center">
        <AnimatedSection delay={200}>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full mb-8">
            <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="text-sm text-gray-300">Available for Premium Projects</span>
          </div>
        </AnimatedSection>

        <AnimatedSection delay={400}>
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent">
              Building
            </span>
            <br />
            <span className="bg-gradient-to-r from-red-500 via-red-600 to-red-700 bg-clip-text text-transparent">
              Premium Real Estate
            </span>
            <br />
            <span className="bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent">
              Websites
            </span>
          </h1>
        </AnimatedSection>

        <AnimatedSection delay={600}>
          <p className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto mb-10 leading-relaxed">
            Transform your property business with stunning, high-converting websites that capture leads and close deals.
          </p>
        </AnimatedSection>

        <AnimatedSection delay={800}>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="mailto:selectgadget56@gmail.com"
              className="group relative px-8 py-4 bg-gradient-to-r from-red-600 to-red-700 rounded-full font-semibold text-lg overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-red-500/40"
            >
              <span className="relative z-10">Start Your Project</span>
              <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-red-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </a>
            <a href="#work" className="px-8 py-4 border border-white/20 rounded-full font-semibold text-lg hover:bg-white/5 transition-all duration-300">
              View My Work
            </a>
          </div>
        </AnimatedSection>

        <AnimatedSection delay={1000}>
          <div className="mt-16 flex items-center justify-center gap-8 text-gray-500">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              <span className="text-white font-semibold">5.0</span>
              <span>Rating</span>
            </div>
            <div className="w-px h-8 bg-gray-700" />
            <div>
              <span className="text-white font-semibold">3+</span> Projects Completed
            </div>
            <div className="w-px h-8 bg-gray-700" />
            <div>
              <span className="text-white font-semibold">100%</span> Client Satisfaction
            </div>
          </div>
        </AnimatedSection>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  )
}

// About Section
const About = () => {
  return (
    <section id="about" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-red-950/10 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <AnimatedSection>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-red-600/20 to-transparent rounded-3xl blur-2xl" />
              <GlassCard className="relative p-8">
                <div className="w-full aspect-square bg-gradient-to-br from-red-600/20 via-red-900/20 to-black rounded-2xl flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-32 h-32 mx-auto bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center mb-4">
                      <span className="font-display text-5xl font-bold text-white">A</span>
                    </div>
                    <p className="text-gray-400">Your Vision, My Code</p>
                  </div>
                </div>
              </GlassCard>
            </div>
          </AnimatedSection>

          <AnimatedSection delay={200}>
            <div>
              <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
                <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                  Crafting Digital
                </span>
                <br />
                <span className="bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">
                  Real Estate Experiences
                </span>
              </h2>
              <p className="text-gray-400 text-lg leading-relaxed mb-6">
                I'm Akash, a passionate real estate website builder specializing in creating stunning, high-converting property websites. With a deep understanding of what makes real estate businesses succeed online, I transform your vision into a digital masterpiece.
              </p>
              <p className="text-gray-400 text-lg leading-relaxed mb-8">
                My expertise lies in combining beautiful design with conversational interfaces that guide visitors toward action. Every website I create is optimized for performance, SEO, and most importantly – results.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="GlassCard p-4">
                  <div className="text-3xl font-bold text-red-500 mb-1">3+</div>
                  <div className="text-gray-400">Projects Delivered</div>
                </div>
                <div className="GlassCard p-4">
                  <div className="text-3xl font-bold text-red-500 mb-1">100%</div>
                  <div className="text-gray-400">Satisfaction Rate</div>
                </div>
                <div className="GlassCard p-4">
                  <div className="text-3xl font-bold text-red-500 mb-1">24h</div>
                  <div className="text-gray-400">Response Time</div>
                </div>
                <div className="GlassCard p-4">
                  <div className="text-3xl font-bold text-red-500 mb-1">Premium</div>
                  <div className="text-gray-400">Quality Focus</div>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}

// Services Section
const Services = () => {
  const services = [
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
      ),
      title: 'Real Estate Website Development',
      description: 'Complete property websites with listings, search functionality, agent profiles, and lead capture forms.',
      features: ['Property Listings', 'Advanced Search', 'Lead Capture', 'Mobile Responsive']
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
        </svg>
      ),
      title: 'Premium Property Design',
      description: 'Luxury-focused designs that showcase properties with elegant galleries, smooth animations, and premium aesthetics.',
      features: ['Luxury Aesthetics', 'Parallax Effects', 'Image Galleries', 'Custom Animations']
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      ),
      title: 'High-Performance Sites',
      description: 'Lightning-fast websites optimized for SEO and conversions, ensuring your properties get maximum visibility.',
      features: ['SEO Optimized', 'Fast Loading', 'Conversion Focused', 'Analytics Setup']
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      ),
      title: 'Mobile-First Experience',
      description: 'Fully responsive designs that look stunning on all devices, from desktop computers to mobile phones.',
      features: ['Responsive Design', 'Touch Friendly', 'All Devices', 'Cross Browser']
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z" />
        </svg>
      ),
      title: 'Custom Integrations',
      description: 'MLS integration, CRM connections, payment gateways, and custom functionality tailored to your needs.',
      features: ['MLS Integration', 'CRM Setup', 'Payment Gateway', 'Custom Features']
    }
  ]

  return (
    <section id="services" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-5xl bg-gradient-to-b from-red-950/20 via-transparent to-transparent rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Premium Services
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Everything you need to establish a powerful online presence in the real estate market
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <AnimatedSection key={index} delay={index * 100}>
              <GlassCard className="group p-8 hover:bg-white/10 transition-all duration-500 h-full">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <h3 className="font-display text-xl font-bold text-white mb-3 group-hover:text-red-400 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-400 mb-6">
                  {service.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, i) => (
                    <span key={i} className="px-3 py-1 text-xs bg-white/5 border border-white/10 rounded-full text-gray-400">
                      {feature}
                    </span>
                  ))}
                </div>
              </GlassCard>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

// Why Work With Me Section
const WhyWorkWithMe = () => {
  const reasons = [
    {
      title: 'Real Estate Specialization',
      description: 'I understand the unique needs of property businesses – from listing management to lead capture and conversion optimization.',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
        </svg>
      )
    },
    {
      title: 'Beauty Meets Function',
      description: "I create websites that are not just visually stunning but also highly functional, ensuring a seamless user experience that converts visitors into clients.",
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
        </svg>
      )
    },
    {
      title: 'Premium Quality Assurance',
      description: 'Every project undergoes rigorous testing and quality checks to ensure pixel-perfect execution and flawless performance.',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
        </svg>
      )
    },
    {
      title: 'Conversational Design',
      description: 'My websites guide visitors naturally through the buyer journey, creating meaningful connections and driving action.',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
      )
    },
    {
      title: 'Fast Turnaround',
      description: 'I value your time. Expect quick delivery without compromising on quality, keeping your project on schedule.',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      )
    },
    {
      title: 'Ongoing Support',
      description: "My relationship doesn't end at delivery. I provide continued support to ensure your website evolves with your business.",
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
      )
    }
  ]

  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-red-950/20 via-transparent to-red-950/20" />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Why Work With Me
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Your success is my priority. Here's what sets me apart
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <AnimatedSection key={index} delay={index * 100}>
              <GlassCard className="p-6 group hover:-translate-y-2 transition-all duration-300">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-600/20 to-red-900/20 flex items-center justify-center text-red-500 mb-4 group-hover:from-red-600/40 group-hover:to-red-900/40 transition-all">
                  {reason.icon}
                </div>
                <h3 className="font-display text-lg font-bold text-white mb-2">
                  {reason.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {reason.description}
                </p>
              </GlassCard>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

// Process Section
const Process = () => {
  const steps = [
    {
      number: '01',
      title: 'Discovery',
      description: 'We discuss your vision, goals, and requirements to understand exactly what you need.',
      details: ['Goal Assessment', 'Brand Analysis', 'Feature Planning', 'Timeline Setup']
    },
    {
      number: '02',
      title: 'Design',
      description: 'I create stunning mockups and prototypes for your approval before any development begins.',
      details: ['UI/UX Design', 'Brand Integration', 'Responsive Layouts', 'Interactive Prototypes']
    },
    {
      number: '03',
      title: 'Develop',
      description: 'Your website is built with precision using modern technologies and best practices.',
      details: ['Clean Code', 'Performance Optimization', 'SEO Setup', 'Mobile First']
    },
    {
      number: '04',
      title: 'Launch',
      description: 'After thorough testing, your website goes live. I ensure everything runs perfectly.',
      details: ['Quality Testing', 'Hosting Setup', 'Training Session', 'Documentation']
    }
  ]

  return (
    <section id="process" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black to-transparent" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                My Process
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              A streamlined workflow designed to deliver exceptional results
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <AnimatedSection key={index} delay={index * 150}>
              <div className="relative group">
                {/* Connection Line */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-12 left-full w-full h-0.5 bg-gradient-to-r from-red-600/50 to-transparent z-0" />
                )}

                <GlassCard className="relative p-6 h-full">
                  <div className="text-5xl font-display font-bold text-red-600/30 mb-4 group-hover:text-red-600/50 transition-colors">
                    {step.number}
                  </div>
                  <h3 className="font-display text-2xl font-bold text-white mb-3">
                    {step.title}
                  </h3>
                  <p className="text-gray-400 mb-4">
                    {step.description}
                  </p>
                  <div className="space-y-2">
                    {step.details.map((detail, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-gray-500">
                        <svg className="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                        {detail}
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

// Work/Portfolio Section
const Work = () => {
  const projects = [
    {
      title: 'Tatu City',
      category: 'Real Estate Development',
      description: 'Modern real estate website for a major development project',
      url: 'https://www.tatucity.com/',
      gradient: 'from-red-600 to-red-900'
    },
    {
      title: 'Volonte Real Estate',
      category: 'Property Agency',
      description: 'Elegant website for a premium property agency in Cambodia',
      url: 'https://www.realestate.com.kh/offices/volonte-real-estate-maharaamonvolonterealestate-7368/',
      gradient: 'from-red-700 to-black'
    },
    {
      title: 'Krishna Valley',
      category: 'Residential Complex',
      description: 'Beautiful website for a luxury residential project in India',
      url: 'https://krishnavalleyvrindavan.com/residential-appartment-vrindavan',
      gradient: 'from-red-800 to-red-950'
    },
    {
      title: "Sotheby's Realty",
      category: 'Luxury Properties',
      description: 'Premium listings portal for luxury real estate',
      url: 'https://www.sothebysrealty.com/',
      gradient: 'from-red-900 to-black'
    },
    {
      title: 'Long Realty',
      category: 'Property Services',
      description: 'Comprehensive real estate services platform',
      url: 'https://www.longrealty.com/realestate/search/741c8497-0101-4bdc-a682-c7bffa5ca669',
      gradient: 'from-red-600 to-red-800'
    }
  ]

  return (
    <section id="work" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-red-950/10 to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Featured Work
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              A selection of my real estate website projects
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <AnimatedSection key={index} delay={index * 100}>
              <a
                href={project.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group block"
              >
                <GlassCard className="overflow-hidden group-hover:bg-white/10 transition-all duration-500">
                  <div className={`h-48 bg-gradient-to-br ${project.gradient} flex items-center justify-center relative overflow-hidden`}>
                    <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors duration-300" />
                    <div className="relative z-10 w-16 h-16 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center">
                      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                      </svg>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-red-500 text-sm font-medium mb-1">{project.category}</p>
                    <h3 className="font-display text-xl font-bold text-white mb-2 group-hover:text-red-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-gray-400 text-sm">
                      {project.description}
                    </p>
                    <div className="mt-4 flex items-center gap-2 text-red-500 text-sm font-medium group-hover:gap-3 transition-all">
                      View Project
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                      </svg>
                    </div>
                  </div>
                </GlassCard>
              </a>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

// Testimonials Section
const Testimonials = () => {
  const testimonials = [
    {
      quote: "Akash transformed our property business with a stunning website that generates leads consistently. His attention to detail and understanding of real estate needs is exceptional.",
      author: "Sarah Mitchell",
      role: "Property Developer",
      avatar: "SM"
    },
    {
      quote: "Working with Akash was a game-changer for our agency. The website he built is not only beautiful but also converts visitors into qualified leads. Highly recommended!",
      author: "Michael Chen",
      role: "Real Estate Agency Owner",
      avatar: "MC"
    },
    {
      quote: "The level of professionalism and quality Akash delivers is outstanding. Our online presence has completely transformed, and we've seen a 200% increase in inquiries.",
      author: "David Thompson",
      role: "Luxury Property Consultant",
      avatar: "DT"
    }
  ]

  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-600/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Client Success
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Building trust through exceptional results
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <AnimatedSection key={index} delay={index * 150}>
              <GlassCard className="p-8 h-full flex flex-col">
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg key={star} className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-gray-300 text-lg leading-relaxed mb-6 flex-grow">
                  "{testimonial.quote}"
                </p>
                <div className="flex items-center gap-4 pt-4 border-t border-white/10">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center">
                    <span className="font-display text-sm font-bold text-white">{testimonial.avatar}</span>
                  </div>
                  <div>
                    <div className="font-display font-bold text-white">{testimonial.author}</div>
                    <div className="text-gray-500 text-sm">{testimonial.role}</div>
                  </div>
                </div>
              </GlassCard>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

// FAQ Section
const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs = [
    {
      question: 'How long does it take to build a real estate website?',
      answer: 'The timeline varies based on project complexity. A standard real estate website typically takes 2-4 weeks, while more complex projects with custom features may take 4-8 weeks. I always provide a detailed timeline during our initial consultation.'
    },
    {
      question: 'What makes your real estate websites different?',
      answer: 'I specialize exclusively in real estate websites, understanding the unique needs of property businesses. My designs combine stunning aesthetics with conversion-focused functionality, ensuring your website not only looks great but also captures and converts leads effectively.'
    },
    {
      question: 'Do you provide hosting and domain services?',
      answer: 'I can recommend trusted hosting providers and assist with domain setup. While hosting is typically a separate ongoing expense, I ensure your website is optimized for the best performance on any quality hosting platform.'
    },
    {
      question: 'Can you integrate with MLS and CRM systems?',
      answer: 'Absolutely! I have experience integrating various MLS feeds, CRM systems, and property management software. During our discovery call, we will discuss which integrations are essential for your business workflow.'
    },
    {
      question: 'What kind of support do you offer after launch?',
      answer: 'I provide comprehensive post-launch support including training on how to manage your content, technical support for any issues, and optional ongoing maintenance plans. I am always available to help as your business evolves.'
    },
    {
      question: 'How do we get started?',
      answer: 'Simply reach out via the contact form or email, and we will schedule a free consultation to discuss your project requirements. From there, I will provide a detailed proposal with pricing and timeline before we begin any work.'
    }
  ]

  return (
    <section id="faq" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Frequently Asked Questions
              </span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Everything you need to know about working together
            </p>
          </div>
        </AnimatedSection>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <AnimatedSection key={index} delay={index * 50}>
              <GlassCard className="overflow-hidden">
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full p-6 text-left flex items-center justify-between"
                >
                  <span className="font-display text-lg font-semibold text-white pr-4">
                    {faq.question}
                  </span>
                  <svg
                    className={`w-5 h-5 text-red-500 flex-shrink-0 transition-transform duration-300 ${openIndex === index ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                <div className={`overflow-hidden transition-all duration-300 ${openIndex === index ? 'max-h-48' : 'max-h-0'}`}>
                  <p className="px-6 pb-6 text-gray-400 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </GlassCard>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}

// CTA Section
const CTA = () => {
  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-red-800/20 to-red-600/20" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-red-600/20 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="font-display text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                Ready to Transform Your
              </span>
              <br />
              <span className="bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">
                Real Estate Business?
              </span>
            </h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
              Let's create a stunning website that captures leads and grows your business.
              Get started with a free consultation today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="mailto:selectgadget56@gmail.com"
                className="group relative px-10 py-4 bg-gradient-to-r from-red-600 to-red-700 rounded-full font-semibold text-lg overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-red-500/40 animate-pulse-glow"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Get Started Now
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-red-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </a>
              <a
                href="mailto:selectgadget56@gmail.com"
                className="px-10 py-4 border border-white/20 rounded-full font-semibold text-lg hover:bg-white/5 transition-all duration-300"
              >
                Contact Me
              </a>
            </div>
            <p className="mt-8 text-gray-500 text-sm">
              Or email directly at{' '}
              <a href="mailto:selectgadget56@gmail.com" className="text-red-500 hover:text-red-400">
                selectgadget56@gmail.com
              </a>
            </p>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}

// Footer
const Footer = () => {
  return (
    <footer className="relative py-16 border-t border-white/10">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center">
              <span className="font-display text-xl font-bold text-white">A</span>
            </div>
            <div>
              <div className="font-display font-bold text-white">Akash</div>
              <div className="text-gray-500 text-sm">Premium Real Estate Websites</div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <a href="mailto:selectgadget56@gmail.com" className="text-gray-400 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </a>
            <a
              href="https://brainbend.gumroad.com/l/clientmagnet"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-full text-sm text-gray-400 hover:text-white hover:bg-white/10 transition-all"
            >
              Gumroad
            </a>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-white/5 text-center">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} Akash. All rights reserved. | Crafted with passion for real estate excellence
          </p>
        </div>
      </div>
    </footer>
  )
}

// Main App Component
function App() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <CustomCursor />
      <Navigation />
      <main>
        <Hero />
        <About />
        <Services />
        <WhyWorkWithMe />
        <Process />
        <Work />
        <Testimonials />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </div>
  )
}

export default App
